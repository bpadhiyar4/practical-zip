public class SnackToCamel {

    public static String camelToSnack(String input) {
        return input.replaceAll("([a-z])([A-Z]+)", "$1_$2").toLowerCase();
    }

    public static String snackToCamel(String input) {
        StringBuilder ansString = new StringBuilder();
        String[] array = input.split("_");
        if(array.length > 1) {
            for (String str : array) {
                ansString.append(str.substring(0, 1).toUpperCase() + str.substring(1));
            }
        }

        return ansString.toString();
    }

    public static void main(String[] args) {
        String input = "";

        // Camel to snack
        input = camelToSnack(input);
        System.out.println("Camel to Snack : " + input);

        // Snack to Camel
        input = snackToCamel(input);
        System.out.println("Snack to Camel : " + input);
    }
}