package com.springpractical.bharat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BharatApplicationTests {

    @Test
    void contextLoads() {
    }

}
